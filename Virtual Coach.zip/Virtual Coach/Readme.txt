Pre-installed:
- E4 stream (wifi)
- TobiiProEyeTrackerManager

Program name:

 TobiiTesting1.exe

Notes:
The usb hub can only load one camera.